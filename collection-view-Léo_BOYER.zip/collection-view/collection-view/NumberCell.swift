//
//  NumberCell.swift
//  collection-view
//
//  Created by  on 16/02/2021.
//

import UIKit

class NumberCell: UICollectionViewCell {
    
    @IBOutlet weak var numberLabel: UILabel!
}

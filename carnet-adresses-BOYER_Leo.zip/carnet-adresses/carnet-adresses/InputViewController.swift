//
//  InputViewController.swift
//  carnet-adresses
//
//  Created by  on 15/02/2021.
//

import UIKit

class InputViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var surnameField: UITextField!
    @IBOutlet weak var phoneField: UITextField!
    
    var name: String = ""
    var surname: String = ""
    var phone: String = ""
    
    @IBAction func onButtonClicked(_ sender: UIButton?) {
        self.performSegue(withIdentifier: "toContacts", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameField.delegate = self
        surnameField.delegate = self
        phoneField.delegate = self

        // Do any additional setup after loading the view.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let text = textField.text {
            if textField == nameField {
                name = text
                surnameField.becomeFirstResponder()
            } else if textField == surnameField {
                surname = text
                phoneField.becomeFirstResponder()
            } else if textField == phoneField {
                phone = text
                textField.resignFirstResponder() // FERME LE CLAVIER
            }
        }
        return true
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toContacts" {
            if let destVC = segue.destination as? ContactsViewController {
                destVC.name = name
                destVC.surname = surname
                destVC.phone = surname
            }
        }
    }

}

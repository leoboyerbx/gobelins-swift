#import "NSData+Nocilla.h"

@implementation NSData (Nocilla)

- (NSData *)data {
    return self;
}

@end

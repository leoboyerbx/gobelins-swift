
import UIKit

struct UserModelUI {
    var id: Int = 0
    var name: String = ""
    var username: String = ""
    var company: String = ""
}

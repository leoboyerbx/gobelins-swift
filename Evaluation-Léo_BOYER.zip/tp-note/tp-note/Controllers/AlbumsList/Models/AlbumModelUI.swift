
import UIKit

struct AlbumModelUI {
    var title: String = ""
    var photos: Photos = []
}
